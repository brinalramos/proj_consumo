export class ConsumoAgua {
  id: number; 
  usuarioId: number; 
  quantidadeConsumida: number;
  dataLeitura: Date;
}

